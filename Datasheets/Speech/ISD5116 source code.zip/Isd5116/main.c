/*****************************************************************************
 * main.c
 *
 * Description:
 * Application code that shows how to use the ISD5116 driver (shell).
 *
 * Author: Martin Dubuc
 *
 * Creation date: January 7, 2003
 *
 * ISD page: http://members.rogers.com/martin.dubuc/Isd
 *
 * Copyright (c) 2003 Martin Dubuc
 ****************************************************************************/
#if 1
#include <16f877.h>

#fuses HS,NOPROTECT,NOWDT,BROWNOUT,PUT,NOLVP

#ORG 0x1F00,0x1FFF {} /* Reserve memory for bootloader for the 8k 16F876/7 */

#device PIC16F877 *=16 /* Allow RAM to expand beyond 256 bytes */
#else
#include <18f452.h>

#fuses NOOSCSEN,HS,BORV20,NOBROWNOUT,PUT,WDT128,NOWDT,CCP2C1,NODEBUG,NOLVP,STVREN,NOPROTECT,NOWRT,NOWRTD,NOWRTB

#device PIC18F452 *=16 /* Allow RAM to expand beyond 256 bytes */

#BUILD(reset=0x200)
#BUILD(interrupt=0x208)

#ORG 0,0x1FF
dummy() {
#ASM
NOP
#ENDASM
} /* Reserve memory for bootloader for the 18F452 */
#endif

#if 0
#device adc=10 /* Make sure that we are sampling on 10 bits. This directive
                  is required for compiler version 2.7. */
#endif

#include "sysdefs.h"

/* Set the clock speed; based on define in sysdefs.h */
#ifdef 20_MHZ_CLOCK
#use delay(clock=20000000)
#else
#use delay(clock=4000000)
#endif

/* Directive for RS-232 interface */
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)

/* Directive for I2C */
#use i2c(MASTER, SDA=PIN_C4, SCL=PIN_C3, FORCE_HW)

#include "sysdefs.h"

#include "isd5116.c"

/*****************************************************************************
 * Init hardware pins: Set up the TRIS, set up analog ports, set the
 * pins to their default values.
 ****************************************************************************/
void
init_pins(void) {
  /* Set up the various pins in/out */
  set_tris_a(0b00000000); /* Port A, except A4 which is not used,
                             is all inputs */
  set_tris_b(0b00110000); /* B1 is output. B4 and B5 are input. Rest is unused */
  set_tris_c(0b10000000); /* C3 is output. C4 is input/output. C7 is input. */
  set_tris_d(0b00000000); /* Port D is not used */
  set_tris_e(0b00000000); /* Port E is not used */
} /* init_pins */

/*****************************************************************************
 * Robot initialization. Initialize pins, global variables, timers and
 * interrupts.
 ****************************************************************************/
void
init(void) {
  init_pins();

  isd_init();

  /* Enable interrupts */
  enable_interrupts(GLOBAL);

  isd_set_config();
} /* init */

/*****************************************************************************
 * This is the main control loop.
 ****************************************************************************/
void
main(void) {
  char cmd;
  uint8_t status;
  char buf[8];
  uint8_t i, j;
  uint16_t addr;

  init();

  printf("ISD5116 shell\r\n\r\n");

  for ( ; ; ) {
    printf("command: ");
    for ( ; ; ) {
      if (kbhit())
        break;

      delay_us(100);
    }

    cmd = getchar();
    printf("%c\r\n", cmd);

    switch(cmd) {
    case 'a':
      addr = isd_read_address();
      printf("%02x%02x\r\n", addr >> 8, addr & 0xff);
      break;
    case 'd':
      isd_power_down();
      break;
    case 'E':
      isd_digital_erase();
      break;
    case 'p':
      isd_play(); 
      break;
    case 'r':
      isd_record();
      break;
    case 'R':
      for (i = 0; i < 32; i++) {
        isd_digital_read(buf, 8);
        /* Display all 8 bytes of data in block */
        for (j = 0; j < 8; j++)
          printf("%02x", buf[j]);

        printf("\r\n");
      }
      break;
    case 's':
      isd_stop();
      break;
    case 'u':
      isd_power_up();
      break;
    case 'W':
      isd_digital_write(buf, 8);
      break;
    case '>':
      isd_message_cue();
      break;
    default:
      printf("invalid command\r\n");
    }
  }
} /* main */
