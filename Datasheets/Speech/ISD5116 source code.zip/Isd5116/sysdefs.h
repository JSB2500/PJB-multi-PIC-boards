/****************************************************************************
 * sysdefs.h
 *
 * Description:
 * System definitions.
 *
 * Author: Martin Dubuc
 *
 * Creation date: July 26, 2001
 *
 * Copyright (c) 2001-2003 Martin Dubuc
 ***************************************************************************/

#ifndef _SYSDEFS_H
#define _SYSDEFS_H

/* The 20_MHZ_CLOCK define is used to indicate whether we are using
   a 4 MHz or 20 MHz clock */
#define 20_MHZ_CLOCK

#define INFINITE (0xffff)

typedef short int BIT;

typedef unsigned int uint8_t;

typedef unsigned long uint16_t;

#endif /* _SYSDEFS_H */
