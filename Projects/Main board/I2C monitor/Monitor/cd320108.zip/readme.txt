--------------------------------------------------------------------------------
Copyright (C) 1997 by D3K, The Artisan Of Ware. All rights reserved.
Copyright (C) 1997 by M. Cocco. All rights reserved.
E-mail: d3k@mdnet.it
URL   : http://www.mdlive.com/d3k/
--------------------------------------------------------------------------------

TCommPortDriver is an invisible component for Delphi 2.0.

It is released as FreeWare. You can use it in commercial and non-commercial
applications provided that a simple acknowledgement is placed somewhere (help
file, about box, readme.xxx, ...).

TCommPortDriver features:
 - supports Delphi 2.0 only (uses Win32 API - COMDRV16.ZIP also available)
 - invisible at run time
 - supports COM1-COM16
 - supports all standard baud rates from 110 to 115200
 - adjustable COM settings (baud rate, byte size, stop bits, parity,
   handshaking)
 - supports NONE, XON/XOFF, RTS/CTS, XON/XOFF + RTS/CTS handshakings
 - send data by calling SendData()/SendString()/... methods
 - receive data asyncronously or synchronously
 - supports variable sized in/out data buffers
 - supports RX packets with timeouts
 - english and italian docs included (plain text)

! Full source code included !

Enjoy!

--------------------------------------------------------------------------------

HOW TO :

- Install TCommPortDriver:

Warning : you must install this component before opening the demo !
          if you open the demo app before doing this, Delphi will
          remove the component declarations from the source code
          and the demo will no longer work !

- To install this component follow the usual steps.
  1. Select <Component|Install...>
  2. Select <Add...> button from the "Install components" dialog box
  3. Select <Browse...> button from the "Add Module" dialog box
  4. Select "CommDrv.pas" and then <OK>
  5. Select <OK> from the <"Install components" dialog box
  6. Delphi will now recompile the components library
  7. All done ! You can find the TCommPortDriver component in the
     component palette ("System" tab)

- Now you can open the demo app (ComTest.DPR) and run it.

If you have throuble feel free to send to d3k@mdnet.it

Hi by M. Cocco

--------------------------------------------------------------------------------

